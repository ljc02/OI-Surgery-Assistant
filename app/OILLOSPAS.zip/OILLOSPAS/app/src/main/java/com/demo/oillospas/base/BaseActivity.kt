package com.demo.authapp.base

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewbinding.ViewBinding

/**
 * Activity 基类
 */
abstract class BaseActivity<VB : ViewBinding, VM: BaseViewModel> : AppCompatActivity() {

    lateinit var binding: VB

    lateinit var viewModel: VM

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = setBinding()
        setContentView(binding.root)
        viewModel = ViewModelProvider(this)[getViewModelClass()]
        initView()
        initListener()
    }

    abstract fun setBinding(): VB

    abstract fun getViewModelClass(): Class<VM>

    abstract fun initView()

    abstract fun initListener()

    open fun showToast(content: String?) {
        runOnUiThread { Toast.makeText(this@BaseActivity, content, Toast.LENGTH_SHORT).show() }
    }

}