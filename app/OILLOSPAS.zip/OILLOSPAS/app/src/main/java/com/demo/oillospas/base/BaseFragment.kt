package com.demo.authapp.base

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewbinding.ViewBinding

abstract class BaseFragment<VB : ViewBinding, VM: BaseViewModel> : Fragment(){

    var TAG = this.javaClass.simpleName

    lateinit var binding: VB

    lateinit var viewModel: VM

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = setBinding()
        viewModel = ViewModelProvider(requireActivity())[getViewModelClass()]
        initView()
        initListener()
        return binding.root
    }

    abstract fun getViewModelClass(): Class<VM>

    abstract fun setBinding(): VB

    abstract fun initView()

    abstract fun initListener()

    fun showToast(content: String?) {
        if (activity?.isFinishing == true) {
            return
        }
        Toast.makeText(activity, content, Toast.LENGTH_SHORT).show()
    }

}