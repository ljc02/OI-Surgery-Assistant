package com.demo.authapp.base

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * viewModel 基类
 */
open class BaseViewModel : ViewModel(){

    // 加载
    val loading = MutableLiveData<Boolean>(false)

    private val coroutineExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        handleException(throwable)
    }

    fun launch(
        block: suspend CoroutineScope.() -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO + coroutineExceptionHandler) {
            block.invoke(this)
        }
    }

    protected fun setLoading(isLoading: Boolean) {
        loading.value = isLoading
    }

    open fun handleException(throwable: Throwable) {
        // 处理异常的逻辑
        Log.e("----FATAL----", throwable.printStackTrace().toString())
    }

}