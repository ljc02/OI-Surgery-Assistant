package com.demo.oillospas.constance


object Constance {
    val BaseUrl = "http://1.12.255.194:8080"
}