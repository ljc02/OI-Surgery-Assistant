package com.demo.oillospas.network.api

import com.demo.oillospas.network.data.Scheme
import com.demo.oillospas.network.data.User
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiService {
    @GET("api/users")
    fun getAllUsers(): Call<List<User>>

    @GET("api/users/{id}")
    fun getUserById(@Path("id") id: String): Call<User>
//
//    @POST("api/users")
//    fun createUser(@Body user: User): Call<User>
//
//    @PUT("api/users/{id}")
//    fun updateUser(@Path("id") id: String, @Body userDetails: User): Call<User>
//
//    @DELETE("api/users/{id}")
//    fun deleteUser(@Path("id") id: String): Call<Void>

    @GET("/api/schemes/user/{userId}")
    fun getSchemesByUserId(@Path("userId") userId: String): Call<List<Scheme>>
}