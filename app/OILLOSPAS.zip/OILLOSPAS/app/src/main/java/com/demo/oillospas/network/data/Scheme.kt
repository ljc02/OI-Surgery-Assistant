package com.demo.oillospas.network.data

data class Scheme(
    val userId: String,
    val schemeNumber: String,
    val schemeContent: String,
    val schemeImageUrl: String?,
    val schemeVideoUrl: String?
)