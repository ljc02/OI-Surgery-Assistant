package com.demo.oillospas.network.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    val id: String,
    val treatmentNumber: String,
    var name: String,
    var age: Int,
    var height: Float,
    var weight: Float
) : Parcelable