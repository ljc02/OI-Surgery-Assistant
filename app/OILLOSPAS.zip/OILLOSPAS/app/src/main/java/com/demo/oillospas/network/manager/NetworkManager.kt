package com.demo.oillospas.network.manager

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import com.demo.oillospas.network.api.ApiService
import com.demo.oillospas.network.data.Scheme
import com.demo.oillospas.network.data.User
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class NetworkManager {
    private val users = MutableLiveData<List<User>>()
    private val schemes = MutableLiveData<List<Scheme>>()

    private lateinit var retrofit: Retrofit
    private lateinit var apiService: ApiService

    fun getUsers() = users

    fun getSchemes() = schemes

    fun init() {
        // 创建HttpLoggingInterceptor并设置其级别
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY // 可以根据需要调整日志级别
        }

        // 使用OkHttpClient构建器添加拦截器
        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .build()

        retrofit = Retrofit.Builder()
            .baseUrl("http://1.12.255.194:8080/") // 确保替换为您的服务器地址
            .client(client) // 设置自定义的OkHttpClient
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(ApiService::class.java)
    }

    fun getAllUsers() {
        apiService.getAllUsers().enqueue(object : Callback<List<User>> {
            override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                if (response.isSuccessful) {
                    users.postValue(response.body() ?: emptyList())
                }
            }

            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                // 错误处理
//                Toast(context, "请求错误，请稍后重试。", Toast.LENGTH_SHORT).show()
            }
        })
    }

    fun getShemeByUserId(userId: String) {
        apiService.getSchemesByUserId(userId).enqueue(object : Callback<List<Scheme>> {
            override fun onResponse(call: Call<List<Scheme>>, response: Response<List<Scheme>>) {
                if (response.isSuccessful) {
                    schemes.postValue(response.body() ?: emptyList())
                }
            }

            override fun onFailure(call: Call<List<Scheme>>, t: Throwable) {
                // 错误处理
//                Toast(context, "请求错误，请稍后重试。", Toast.LENGTH_SHORT).show()
            }
        })
    }
}