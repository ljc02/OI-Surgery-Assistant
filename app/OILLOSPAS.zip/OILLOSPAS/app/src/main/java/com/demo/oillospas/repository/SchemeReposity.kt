package com.demo.oillospas.repository

import com.demo.oillospas.network.data.Scheme

object SchemeReposity {
    private lateinit var schemes: List<Scheme>

    fun setSchemes(schemes: List<Scheme>) {
        this.schemes = schemes
    }

    fun getSchemes() = schemes
}