package com.demo.oillospas.repository

import com.demo.oillospas.network.data.User


object UserRepository {
    private lateinit var users: List<User>

    fun setUsers(users: List<User>) {
        this.users = users
    }

    fun getUsers() = users
}