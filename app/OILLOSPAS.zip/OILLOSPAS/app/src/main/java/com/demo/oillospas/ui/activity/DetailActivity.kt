package com.demo.oillospas.ui.activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.demo.authapp.base.BaseActivity
import com.demo.oillospas.R
import com.demo.oillospas.databinding.ActivityDetailBinding
import com.demo.oillospas.network.data.User
import com.demo.oillospas.ui.fragment.DetailFragment
import com.demo.oillospas.ui.fragment.ListFragment
import com.demo.oillospas.vm.SchemeViewModel

class DetailActivity : BaseActivity<ActivityDetailBinding, SchemeViewModel>() {
    private var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 检查是否已经保存了状态，避免重复加载
        if (savedInstanceState == null) {
            loadFragments()
        }
    }

    override fun onResume() {
        super.onResume()
        user = intent.getParcelableExtra("user")
        if (user != null) {
            viewModel.getSchemeByUserId(user!!.id)
        }
    }

    override fun setBinding() = ActivityDetailBinding.inflate(layoutInflater)

    override fun getViewModelClass() = SchemeViewModel::class.java

    override fun initView() {
        viewModel.init()
    }

    override fun initListener() {

    }

    private fun loadFragments() {
        val listFragment: Fragment = ListFragment()
        val detailFragment: Fragment = DetailFragment()

        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_list, listFragment)
            .add(R.id.fragment_detail, detailFragment)
            .commit()
    }
}