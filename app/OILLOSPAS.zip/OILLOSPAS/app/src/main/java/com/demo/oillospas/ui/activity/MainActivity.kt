package com.demo.oillospas.ui.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.demo.authapp.base.BaseActivity
import com.demo.oillospas.adapter.SearchAdapter
import com.demo.oillospas.databinding.ActivityMainBinding
import com.demo.oillospas.network.data.User
import com.demo.oillospas.network.manager.NetworkManager
import com.demo.oillospas.vm.SchemeViewModel

class MainActivity : BaseActivity<ActivityMainBinding, SchemeViewModel>() {
    private lateinit var adapter: SearchAdapter
    private lateinit var userList: List<User>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun setBinding() = ActivityMainBinding.inflate(layoutInflater)

    override fun getViewModelClass() = SchemeViewModel::class.java

    override fun initView() {
        userList = viewModel.getUserList()
        adapter = SearchAdapter(userList) { selectedItem ->
            Intent(this, DetailActivity::class.java).apply {
                putExtra("user", selectedItem)
                startActivity(this)
            }
        }
        binding.matchResultList.adapter = adapter
        binding.matchResultList.layoutManager = LinearLayoutManager(this)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun initListener() {
        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val filterResults = if (s.isNullOrEmpty()) {
                    emptyList()
                } else {
                    userList.filter {
                        it.name.contains(s.toString(), ignoreCase = true)
                                || it.treatmentNumber.contains(s.toString(), ignoreCase = true)
                    }
                }
                if (filterResults.toMutableList().size > 0) {
                    binding.matchResultList.visibility = View.VISIBLE
                    adapter.updateData(filterResults.toMutableList())
                } else {
                    binding.matchResultList.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.searchButton.setOnClickListener {
            // 搜索按钮点击事件处理（如果需要的话）
        }
    }
}