package com.demo.oillospas.ui.activity

import android.content.Intent
import android.os.Bundle
import com.demo.authapp.base.BaseActivity
import com.demo.oillospas.databinding.ActivitySplashBinding
import com.demo.oillospas.vm.SchemeViewModel

class SplashActivity : BaseActivity<ActivitySplashBinding, SchemeViewModel>() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.init()
        viewModel.getAllUsers()
    }

    override fun setBinding() = ActivitySplashBinding.inflate(layoutInflater)

    override fun getViewModelClass() = SchemeViewModel::class.java

    override fun initView() {

    }

    override fun initListener() {
        viewModel.getUserObserver().observe(this) {
            if (it != null) {
                val intent = Intent(this@SplashActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}