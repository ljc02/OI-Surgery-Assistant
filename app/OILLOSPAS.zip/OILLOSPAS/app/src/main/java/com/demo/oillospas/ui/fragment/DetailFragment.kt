package com.demo.oillospas.ui.fragment

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import com.demo.authapp.base.BaseFragment
import com.demo.oillospas.R
import com.demo.oillospas.constance.Constance
import com.demo.oillospas.databinding.FragmentDetailBinding
import com.demo.oillospas.network.data.Scheme
import com.demo.oillospas.vm.SchemeViewModel
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackParameters
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout

class DetailFragment : BaseFragment<FragmentDetailBinding, SchemeViewModel>() {
    private var schemes: List<Scheme>? = null
    private var player: ExoPlayer? = null
    private var isFullscreen = false // 用于跟踪是否处于全屏模式
    private var aspectRatio16_9 = true // 跟踪当前宽高比是否为16:9
    private var originalOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var originalSystemUiVisibility: Int = 0
    private var originalParams: ViewGroup.LayoutParams? = null
    private var originalParent: ViewGroup? = null
    private var originalIndex = 0

    override fun getViewModelClass() = SchemeViewModel::class.java

    override fun setBinding() = FragmentDetailBinding.inflate(layoutInflater)

    override fun initView() {
        player = ExoPlayer.Builder(requireActivity()).build()
        binding.videoView.player = player

        initControlButtons()

        binding.tab1.isSelected = true

        // 默认设置视频比例为16:9
//        setAspectRatio(aspectRatio16_9)
    }

    private fun initControlButtons() {
        binding.btnPlayPause.setOnClickListener {
            if (player?.isPlaying == true) {
                player?.pause()
                binding.btnPlayPause.setImageResource(R.drawable.ic_play)
            } else {
                player?.play()
                binding.btnPlayPause.setImageResource(R.drawable.ic_pause)
            }
        }

        binding.videoView.setOnLongClickListener {
            player!!.playbackParameters = PlaybackParameters(2f)
            true
        }

        binding.btnRewind.setOnClickListener {
            player?.currentPosition?.minus(5000)?.let { it1 -> player?.seekTo(it1) }
        }

        binding.btnFastForward.setOnClickListener {
            player?.currentPosition?.plus(5000)?.let { it1 -> player?.seekTo(it1) }
        }

        binding.btnFullScreen.setOnClickListener {
            toggleVideoFullscreen()
        }

        binding.videoView.setOnClickListener {
            if(isFullscreen) {
                toggleVideoFullscreen()
            }
        }

        binding.btnAspectRatio.setOnClickListener {
            aspectRatio16_9 = !aspectRatio16_9
            setAspectRatio(aspectRatio16_9)
        }

        binding.tab1.setOnClickListener {
            setPlayer(0)
            binding.tab1.isSelected = true
            binding.tab2.isSelected = false
            binding.tab3.isSelected = false
            binding.tab4.isSelected = false
        }

        binding.tab2.setOnClickListener {
            setPlayer(1)
            binding.tab1.isSelected = false
            binding.tab2.isSelected = true
            binding.tab3.isSelected = false
            binding.tab4.isSelected = false
        }

        binding.tab3.setOnClickListener {
            setPlayer(2)
            binding.tab1.isSelected = false
            binding.tab2.isSelected = false
            binding.tab3.isSelected = true
            binding.tab4.isSelected = false
        }

        binding.tab4.setOnClickListener {
            setPlayer(3)
            binding.tab1.isSelected = false
            binding.tab2.isSelected = false
            binding.tab3.isSelected = false
            binding.tab4.isSelected = true
        }

        player?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying) {
                    binding.btnPlayPause.setImageResource(R.drawable.ic_play)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && player?.playWhenReady == true) {
                    binding.btnPlayPause.setImageResource(R.drawable.ic_pause)
                }
            }
        })
    }

    @SuppressLint("ResourceAsColor")
    private fun toggleVideoFullscreen() {
        val activity = requireActivity()
        val decorView = activity.window.decorView
        val window = activity.window

        if (isFullscreen) {
            // 退出全屏逻辑
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            decorView.systemUiVisibility = originalSystemUiVisibility
            activity.requestedOrientation = originalOrientation

            // 将视频容器移回原始位置
            val rootView = activity.findViewById<ViewGroup>(android.R.id.content)
            rootView.removeView(binding.videoContainer)
            originalParent?.removeView(binding.controlLayout)
            originalParent?.apply {
                addView(binding.videoContainer, originalIndex, originalParams)
                addView(binding.controlLayout)
            }
//            originalParent?.addView(binding.videoContainer)
//            originalParent?.addView(binding.controlLayout)
        } else {
            // 进入全屏前保存原始信息
            originalParent = binding.videoContainer.parent as? ViewGroup
            originalIndex = originalParent?.indexOfChild(binding.videoContainer) ?: 0
            originalParams = binding.videoContainer.layoutParams

            // 进入全屏逻辑
            originalOrientation = activity.requestedOrientation
            originalSystemUiVisibility = decorView.systemUiVisibility

            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

            // 安全移除并重新添加视图
            originalParent?.removeView(binding.videoContainer)
            val rootView = activity.findViewById<ViewGroup>(android.R.id.content)
            rootView.addView(binding.videoContainer, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }

        binding.videoView.resizeMode = if (isFullscreen) {
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        } else {
            AspectRatioFrameLayout.RESIZE_MODE_FIT
        }

        isFullscreen = !isFullscreen
    }

    private fun setAspectRatio(aspectRatio16_9: Boolean) {
        binding.videoView.apply {
            useController = false // 需要时关闭默认控制器
            resizeMode = if (aspectRatio16_9) {
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            } else {
                AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        }
    }

    override fun initListener() {
        viewModel.getSchemeObserver().observe(requireActivity()) {
            if (it != null && it.isNotEmpty()) {
                schemes = it
                setPlayer(0)
            }
        }
    }

    fun setPlayer(idx: Int) {
        if (schemes != null && schemes!!.size > idx) {
            val mediaItem =
                MediaItem.fromUri(Uri.parse(Constance.BaseUrl + schemes!![idx].schemeVideoUrl))
            player?.setMediaItem(mediaItem)
            player?.prepare()
        }
    }

    override fun onDestroyView() {
        requireActivity().window.decorView.systemUiVisibility = originalSystemUiVisibility
        super.onDestroyView()
        player?.release()
        player = null
    }
}