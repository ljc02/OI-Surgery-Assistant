package com.demo.oillospas.ui.fragment

import android.content.Intent
import android.view.View
import com.bumptech.glide.Glide
import com.demo.authapp.base.BaseFragment
import com.demo.oillospas.R
import com.demo.oillospas.constance.Constance
import com.demo.oillospas.databinding.FragmentListBinding
import com.demo.oillospas.network.data.User
import com.demo.oillospas.ui.activity.MainActivity
import com.demo.oillospas.vm.SchemeViewModel

class ListFragment : BaseFragment<FragmentListBinding, SchemeViewModel>() {
    private var user: User? = null
    private var isShowInfo = false
    private var isShowPlan = false

    override fun getViewModelClass() = SchemeViewModel::class.java

    override fun setBinding() = FragmentListBinding.inflate(layoutInflater)

    override fun initView() {
        user = requireActivity().intent.getParcelableExtra("user")
        if (user != null) {
            binding.tvName.text = user!!.name
            binding.tvAge.text = user!!.age.toString()
            binding.tvHeight.text = user!!.height.toString()
            binding.tvWeight.text = user!!.weight.toString()
        }

    }

    override fun initListener() {
        binding.btnInformation.setOnClickListener {
            if (isShowInfo) {
                binding.llInformation.visibility = View.GONE
                binding.ivInformation.setImageResource(R.drawable.ic_show)
            } else {
                binding.llInformation.visibility = View.VISIBLE
                binding.ivInformation.setImageResource(R.drawable.ic_hide)
            }
            isShowInfo = !isShowInfo
        }
        binding.btnPlan.setOnClickListener {
            if (isShowPlan) {
                binding.llPlan1.visibility = View.GONE
                binding.llPlan2.visibility = View.GONE
                binding.llPlan3.visibility = View.GONE
                binding.ivPlan.setImageResource(R.drawable.ic_show)
            } else {
                binding.llPlan1.visibility = View.VISIBLE
                binding.llPlan2.visibility = View.VISIBLE
                binding.llPlan3.visibility = View.VISIBLE
                binding.ivPlan.setImageResource(R.drawable.ic_hide)
            }
            isShowPlan = !isShowPlan
        }
        binding.btnBack.setOnClickListener {
            val intent = Intent(requireActivity(), MainActivity::class.java)
            requireActivity().startActivity(intent)
            requireActivity().finish()
        }
        viewModel.getSchemeObserver().observe(requireActivity()) {
            if (it != null && it.size >= 3) {
                binding.tvPlan1.text = it[0].schemeContent
                binding.tvPlan2.text = it[1].schemeContent
                binding.tvPlan3.text = it[2].schemeContent
                Glide.with(this)
                    .load(Constance.BaseUrl + it[0].schemeImageUrl)
                    .into(binding.ivPlan1)
                Glide.with(this)
                    .load(Constance.BaseUrl + it[1].schemeImageUrl)
                    .into(binding.ivPlan2)
                Glide.with(this)
                    .load(Constance.BaseUrl + it[2].schemeImageUrl)
                    .into(binding.ivPlan3)
            }
        }
    }
}