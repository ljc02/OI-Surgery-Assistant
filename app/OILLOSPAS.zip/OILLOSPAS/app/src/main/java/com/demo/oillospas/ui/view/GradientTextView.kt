package com.demo.oillospas.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.demo.oillospas.R

class GradientTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : AppCompatTextView(context, attrs, defStyleAttr) {

    override fun onDraw(canvas: Canvas) {
        val paint = paint
        val width = paint.measureText(text.toString())
        val textShader: Shader = LinearGradient(
            0f,
            0f,
            width,
            textSize,
            intArrayOf(context.getColor(R.color.gradient_start_color), context.getColor(R.color.gradient_end_color)), // 渐变的颜色数组
            floatArrayOf(0f, 1f), // 颜色分布位置
            Shader.TileMode.CLAMP
        )
        paint.shader = textShader
        super.onDraw(canvas)
    }
}