package com.demo.oillospas.vm

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.demo.authapp.base.BaseViewModel
import com.demo.oillospas.network.data.Scheme
import com.demo.oillospas.network.data.User
import com.demo.oillospas.network.manager.NetworkManager
import com.demo.oillospas.repository.UserRepository

class SchemeViewModel : BaseViewModel() {
    private val networkManager = NetworkManager()
    private val userList = MutableLiveData<List<User>>()
    private val schemeList = MutableLiveData<List<Scheme>>()

    fun init() {
        networkManager.init() // 初始化网络管理器
        initObserver()
    }

    private fun initObserver() {
        networkManager.getUsers().observeForever { users ->
            UserRepository.setUsers(users)
            userList.postValue(users)
        }
        networkManager.getSchemes().observeForever { schemes ->
            schemeList.postValue(schemes)
        }
    }

    fun getAllUsers() = networkManager.getAllUsers() // 获取所有用户数据

    fun getSchemeByUserId(userId: String) = networkManager.getShemeByUserId(userId)

    fun getSchemeObserver() = schemeList

    fun getUserObserver() = userList

    fun getUserList() = UserRepository.getUsers()
}